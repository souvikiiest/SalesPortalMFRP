declare const styles: {
    app: string;
    top: string;
    bottom: string;
    topnav: string;
    active: string;
    right: string;
};
export default styles;
//# sourceMappingURL=HomepageApplication.module.scss.d.ts.map
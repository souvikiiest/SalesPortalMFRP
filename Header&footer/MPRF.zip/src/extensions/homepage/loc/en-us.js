define([], function() {
  return {
    "Title": "HomepageApplicationCustomizer"
  }
});
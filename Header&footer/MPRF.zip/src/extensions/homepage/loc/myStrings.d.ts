declare interface IHomepageApplicationCustomizerStrings {
  Title: string;
}

declare module 'HomepageApplicationCustomizerStrings' {
  const strings: IHomepageApplicationCustomizerStrings;
  export = strings;
}

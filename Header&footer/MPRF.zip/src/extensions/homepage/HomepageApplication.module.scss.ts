/* tslint:disable */
require("./HomepageApplication.module.css");
const styles = {
  app: 'app_db3f9d43',
  top: 'top_db3f9d43',
  bottom: 'bottom_db3f9d43',
  topnav: 'topnav_db3f9d43',
  active: 'active_db3f9d43',
  right: 'right_db3f9d43'
};

export default styles;
/* tslint:enable */